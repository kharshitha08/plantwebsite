# Houseplant Shop
A React-Redux project featuring a product listing, shopping cart, and landing page.